// Import the functions you need from the SDKs you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-analytics.js";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
apiKey: "AIzaSyCo-_HAC6InFy4jB3bgK3YDWbgx7iF3myA",
authDomain: "inha-f4041.firebaseapp.com",
projectId: "inha-f4041",
storageBucket: "inha-f4041.appspot.com",
messagingSenderId: "898288177179",
appId: "1:898288177179:web:1028a1350def6ced15e8be",
measurementId: "G-20JYZ8X2FQ"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig); //외부에서 쓰기 위해서 export 
const analytics = getAnalytics(app);